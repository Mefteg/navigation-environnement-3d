Pour lancer le programme:
- Aller dans OpenGL/scene
- executer ./princ <scene> <personnage>
- Remplacer <scene> par une scene se situant dans obj/ ( exemple labyrinthe_Scene.obj )
- Remplacer <personnage> par un personnage se situant dans obj/ ( exemple: robot_Scene.obj )
- appuyer sur h pour voir la liste des commandes disponibles
